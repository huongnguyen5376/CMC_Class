package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import model.UserInfo;

/**
 * description:
 * @author User
 * @modifier User
 * @date: Dec 8, 2017
 * @modifi_note:
 * @modifi_date: Dec 8, 2017
 */

public class UserInfoDAO {
	
	JdbcTemplate template;
	
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	
	public int insertUser(UserInfo info) {
		String sql = "insert into UserInfo(UserName,UserPassword) values ('" 
				+ info.getUsername() + "','" + info.getPassword() + "')";
		return template.update(sql);
	}
	
    public int update(UserInfo info) {
      String sql = "update UserInfo set UserName='" + info.getUsername() 
                + "', UserPassword='" + info.getPassword() + "' where UserID=" 
                + info.getId() + "";
      return template.update(sql);
  }

  public int delete(int id) {
      String sql = "delete from UserInfo where UserID=" + id + "";
      return template.update(sql);
  }

  public UserInfo getUserById(int id) {
      String sql = "select * from UserInfo where UserID=?";
      return template.queryForObject(sql, new Object[] { id }, new BeanPropertyRowMapper<UserInfo>(UserInfo.class));
  }

  public List<UserInfo> getAllUser() {
      return template.query("select * from UserInfo", new RowMapper<UserInfo>() {
          public UserInfo mapRow(ResultSet rs, int row) throws SQLException {
            UserInfo info = new UserInfo();
            info.setId(rs.getInt(1));
            info.setUsername(rs.getString(2));
            info.setPassword(rs.getString(3));
            return info;
          }
      });
    }
  
  public UserInfo getUserInfo(String username, String password) {
    String sql = "select * from UserInfo where UserName=? and UserPassword=?";
    return template.queryForObject(sql, new Object[] { username, password }, 
              new BeanPropertyRowMapper<UserInfo>(UserInfo.class));
  }
}
