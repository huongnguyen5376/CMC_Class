/**
 * 
 */
package controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import dao.UserInfoDAO;
import model.UserInfo;

/**
 * description:
 * @author User
 * @modifier User
 * @date: Dec 8, 2017
 * @modifi_note:
 * @modifi_date: Dec 8, 2017
 */
public class UserInfoController {
     
    @Autowired
    UserInfoDAO infoDAO;
    
    @RequestMapping(value="", method=RequestMethod.POST)
    public ModelAndView displayLogin(HttpServletRequest request, HttpServletResponse response) {
        ModelAndView view = new ModelAndView("");
        UserInfo info = new UserInfo();
        view.addObject("userInfo", info);
        return view;
    }
}
